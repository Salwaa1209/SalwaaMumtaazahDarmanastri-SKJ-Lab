#include <iostream>
using namespace std;

int main(){
    double num1 = 5, num2 = 10, result = 0;
    result = num1 * num2;;
    cout << "The product of two numbers = " << result;

    return 0;
}